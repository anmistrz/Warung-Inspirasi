/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warunginspirasi;

/**
 *
 * @author seno
 */
public class menuMakananMinuman extends WarungSolo{
    int hargaSerabi = 2500;
    int porsiSerabi= 0;
    int hargaNasi = 10000;
    int hargaEsKapal = 6000;
    int hargaWedangRonde = 7000;
    
    void hitungSerabi(){
            int hargaTotal = hargaSerabi * porsiSerabi;
    };
}
